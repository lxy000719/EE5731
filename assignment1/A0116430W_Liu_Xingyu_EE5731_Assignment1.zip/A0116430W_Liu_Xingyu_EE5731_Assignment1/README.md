## EE5731 Visual Computing Assignment 1

The assignment is splitted into 6 parts. Each part has a folder and each folder contains the original imag(s), code file(s) and result image(s)

The main program code file for each part is named as part1, part2,..., part6. The rest are function files

Please ensure the original image(s), main program code file and relevant function files are in the same folder and run to the main program code to get the results.

The report is named as 'A0116430W_Liu_Xingyu_EE5731_Assignment1' and it is in pdf format
